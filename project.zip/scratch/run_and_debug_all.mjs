import { chromium } from 'playwright';

(async () => {
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    
    page.on('console', msg => {
        console.log('BROWSER LOG:', msg.type(), msg.text());
    });
    page.on('pageerror', err => {
        console.log('BROWSER ERROR:', err.message);
    });

    await page.goto('http://localhost:3000/');
    await page.waitForSelector('.layout-selector-group');
    await page.click('.layout-category-btn[data-category="3-window"]');
    await page.waitForTimeout(500);
    await page.click('.layout-submenu-btn[data-layout-id="vertical-3-left-fixed-right"]');
    await page.waitForTimeout(2000);
    await browser.close();
})().catch(console.error);
