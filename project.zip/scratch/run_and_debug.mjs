import { chromium } from 'playwright';

(async () => {
    console.log("Launching headless browser...");
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    
    page.on('console', msg => {
        if (msg.text().includes('DEBUG') || msg.text().includes('fixedBoundaryMm')) {
            console.log('BROWSER LOG:', msg.text());
        }
    });

    console.log("Navigating to http://localhost:3000/ ...");
    await page.goto('http://localhost:3000/');
    
    await page.waitForSelector('.layout-selector-group');
    await page.waitForTimeout(1000);
    
    // Click '3 window' category
    console.log("Clicking '3 window' category...");
    await page.click('.layout-category-btn[data-category="3-window"]');
    await page.waitForTimeout(1000);
    
    // Click vertical-3-left-fixed-right option
    console.log("Clicking vertical-3-left-fixed-right option...");
    await page.click('.layout-submenu-btn[data-layout-id="vertical-3-left-fixed-right"]');
    await page.waitForTimeout(2000);
    
    console.log("Closing browser.");
    await browser.close();
})().catch(err => {
    console.error("Failed:", err);
    process.exit(1);
});
